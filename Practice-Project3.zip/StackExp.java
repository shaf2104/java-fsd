package Assesement;
import java.util.Stack;
public class StackExp {
	public static void main(String[]args) {
		Stack q=new Stack();
		q.push("Lenovo");
		q.push("Avita");
		q.push("HCL");
		q.push("Asus");
		q.push("Dell");
		System.out.println("The total elements are "+q);
		System.out.println("The elements popped is "+q.pop());
		System.out.println("The Remaining elements are "+q);
	}

}
