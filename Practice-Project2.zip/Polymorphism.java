
public class Polymorphism {
	void dis(int regno,int marks) {
		System.out.println("The regno is "+regno +"mark is "+marks);
		
	}
	void dis(String name,int regno,int marks) {
		System.out.println("The regno is "+regno + "name is "+ name +"mark is "+marks);
	}
	void dis(int regno) {
		System.out.println("The regno is "+regno);
	}
	public static void main(String[]args) {
		Polymorphism input=new Polymorphism();
		input.dis(123,98);
		input.dis(456);
		input.dis("priya",132,89);
		
	}

}
