class Info{
                private String name="asika";
                public String fname = "akash";
                protected String lname="janani";
                {
                System.out.println("private name:"+" "+name);
                }
}
                public class Modifiers{
                  public static void main(String[] args) {
                                Info obj=new Info();
                                System.out.println("print public name:"+" "+obj.fname);
                                System.out.println("print protected name:"+" "+obj.lname);
                    }
                }

