public class typecasting  {
	public static void main(String[]args) {
		byte a=10;
		float b=a;  //implicit type casting
		System.out.println(b);
		
		double c=10.12;
		int d=(int)c; //explicit type casting
		System.out.println(d);
		
	}

}
