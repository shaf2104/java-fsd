interface Name1{
	default void dis() {
		System.out.println("AKASH");
	}
}
interface Name2{
	default void dis() {
		System.out.println("PREETHI");
	}
}
public class Diamond implements Name1,Name2
{
	public void dis() {
		Name1.super.dis();
		Name2.super.dis();
	}
	

	public static void main(String[] args) {
		Diamond obj=new Diamond();
		obj.dis();

	}

}
