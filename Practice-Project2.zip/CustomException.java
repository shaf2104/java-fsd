class Myexception extends Exception{
	public Myexception() {
		
	}
	public Myexception(String msg) {
		super(msg);
	}
}
public class CustomException {

	public static void main(String[] args) {
		int a=10;
		int b=5;
		try {
			if(a>b) {
				throw new Myexception("a>b");
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		

	}

}
