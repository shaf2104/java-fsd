class Student{
	void dis1() {
	System.out.println("Name of the student is Shabhana");

}
}
class Details extends Student {
	void dis2() {
	System.out.println("The total marks of shabhana is 496");
}
}
public class Inheritance {

	public static void main(String[] args) {
		Student obj1=new Student();
		obj1.dis1();
		Details obj2=new Details();
		obj2.dis2();
		obj2.dis1();

	}

}
