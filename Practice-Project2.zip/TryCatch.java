
public class TryCatch {

	public static void main(String[] args) {
		try {
		int num[]= {1,2,3,4};
		System.out.println(num[6]);
		}catch(Exception e) {
			
			System.out.println(e);
			
		}
		

	}

}
