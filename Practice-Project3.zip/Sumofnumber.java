package practice;
import java.util.*;
public class Sumofnumber{


static int findSum(int L, int R)
{

	
	int sum = 0, d = R - L + 1;

	for (int i = L; i <= R; i++) {
		sum += (i * d);
		d--;
	}

	
	return sum;
}


public static void main(String args[])
{
	int L=4 ,R=8;

	
	System.out.println(findSum(L, R));

}




}


