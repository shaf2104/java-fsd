
public class MyThreadd extends Thread{
	public void display() {
		System.out.println("Welcome to java");
	}

	public static void main(String[] args) {
		MyThreadd obj=new MyThreadd();
		obj.display();
		

	}

}
