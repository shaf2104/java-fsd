abstract class Car{
	abstract void mileage();
	void colour() {
		System.out.println("White");
	}
}
class Maruthi extends Car{
	void speed() {
		System.out.println("55km/hr");
	}
	void mileage() {
		System.out.println("45km/hr");
	}
	

}
public class Abstraction {

	public static void main(String[] args) {
		Maruthi obj=new Maruthi();
		obj.speed();
		obj.mileage();
		obj.colour();
			
		

	}

}
