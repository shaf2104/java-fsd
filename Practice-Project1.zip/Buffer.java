
public class Buffer {
	public static void main(String[]args) {
		  String str="Welcome";
          StringBuffer object = new StringBuffer(str);
          object.reverse();
          System.out.println(object);
	}
}


