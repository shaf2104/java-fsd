
public class ThrowFinally {

	public static void main(String[] args)throws Exception {
        try {
            int a=10,b=0;
            System.out.println(a/b);
        }catch(Exception e) {
        	System.out.println(e);
        }
        finally
        {
        System.out.println("Error occured");
        }
	}
}
       


            

           







		


