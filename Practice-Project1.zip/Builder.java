class Builder{
	public static void main(String[]args) {
		StringBuilder object=new StringBuilder("Hello");
		object.append("World");
		System.out.println(object);
		
	}
}



                
               

