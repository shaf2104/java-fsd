package Assignment4;
import java.util.Arrays;


public class Binarysearch {
	public static void main(String args[]){  
		int num = 30;
		int arr[] = {10,20,30,40,50};  
		int result = Arrays.binarySearch(arr,num);  
        if (result < 0)  
            System.out.println("Element is not found!");  
        else  
            System.out.println("Element is found at index: "+result);  
    }  
}  

