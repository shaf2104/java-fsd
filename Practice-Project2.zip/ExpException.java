class Myexception extends Exception{
	public Myexception() {
		
	}
	public Myexception(String info) {
		
		
	}
}
public class ExpException {

	public static void main(String[] args) {
		int balance=10000;
		try {
			if(balance>0) {
				throw new Myexception("Insufficient balance");
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		

	}

}
